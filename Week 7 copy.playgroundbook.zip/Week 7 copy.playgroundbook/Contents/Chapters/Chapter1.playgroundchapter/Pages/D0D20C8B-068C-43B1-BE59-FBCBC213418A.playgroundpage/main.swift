
import PlaygroundSupport
import Foundation

PlaygroundPage.current.needsIndefiniteExecution = true
// Below are the functions of a data processing app.

func performDownload() {
    // Perform download here.
    Thread.sleep(forTimeInterval: 2)
    print("downloading JSON")
}

func performJSONParsing() {
    // JSON parsing here.
    Thread.sleep(forTimeInterval: 4)
    print("parsing JSON")
}

func performDBUpdate() {
    // Update DB here.
    Thread.sleep(forTimeInterval: 1)
    print("update DB")
}

// Queues
let dataProcessQueue = OperationQueue()
dataProcessQueue.qualityOfService = .userInitiated
dataProcessQueue.maxConcurrentOperationCount = 3

// Using blocks with OperationQueue result in the wrong order. 
//
//dataProcessQueue.addOperation {
//    performDownload()
//}
//
//dataProcessQueue.addOperation {
//    performJSONParsing()
//}
//
//dataProcessQueue.addOperation {
//    performDBUpdate()
//}

// Using BlockOperations fix the order of data processing. 
let downloadOp = BlockOperation()

downloadOp.addExecutionBlock {
    performDownload()
    performJSONParsing()
}
let updateDBOp = BlockOperation {
    performDBUpdate()
}
updateDBOp.addDependency(downloadOp)

dataProcessQueue.addOperations([downloadOp, updateDBOp], waitUntilFinished: true)


