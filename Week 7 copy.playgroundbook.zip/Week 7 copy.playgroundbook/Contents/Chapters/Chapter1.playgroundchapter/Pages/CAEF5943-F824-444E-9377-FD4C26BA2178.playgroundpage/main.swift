import Foundation
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

// Currently Tomatoes & Apples are printed synchronously.
// Modify the DispatchQueues so Tomatoes & Apples are printed asynchronously. 

DispatchQueue(label: "com.raywenderlich.queue1").async {
    for i in 0..<10 {
        print("🍅 ", i)
    }
}

DispatchQueue(label: "com.raywenderlich.queue2").async {
    for i in 100..<110 {
        print("🍏 ", i)
    }
}

