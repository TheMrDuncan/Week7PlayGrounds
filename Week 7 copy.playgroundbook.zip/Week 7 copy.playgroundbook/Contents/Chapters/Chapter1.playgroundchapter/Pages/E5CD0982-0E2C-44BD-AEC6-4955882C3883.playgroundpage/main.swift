import Foundation
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

// Add appropriate QOS to show avocado toast is more important than pineapple pizza.

let pineapplePizzaQueue = DispatchQueue( label: "com.raywenderlich.queue1", qos: .background)
let avocadoToastQueue = DispatchQueue(label: "com.raywenderlich.queue2", qos: .userInteractive)

pineapplePizzaQueue.async {
    for i in 1..<20 {
        breakfast("🍕🍍")
    }
}

avocadoToastQueue.async {
    for i in 1..<20 {
        breakfast("🥑🥪")
    }
}

PlaygroundPage.current.finishExecution()

// QoS does not assign priority to specific tasks, it works to achive efficency more that anything else.
