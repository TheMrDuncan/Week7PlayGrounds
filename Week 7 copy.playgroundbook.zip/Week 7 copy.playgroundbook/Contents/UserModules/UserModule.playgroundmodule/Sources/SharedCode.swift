// Code inside modules can be shared between pages and other source files.

import Foundation

//To prevent thread print to mix output in the console
//Using a serial DispatchQueue to serialize your print calls 
private let printQueue = DispatchQueue(label: "aprint", qos: .utility)

public func breakfast(_ message: String){
    printQueue.async {
        print(message)
    }
}
